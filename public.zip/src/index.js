import React from 'react';
import ReactDOM from 'react-dom';

import JobBoardWrapper from './Pages/JobBaord'

import './index.css';


function Root() {
  return (
    <>
      <JobBoardWrapper />
    </>
  );
}

ReactDOM.render(
  <React.StrictMode>
    <Root />
  </React.StrictMode>,
  document.getElementById('root')
);


