import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import { headerStyle } from '../jss/styles'
import { Typography, Container, Grid, Button } from '@material-ui/core'

const useStyles = makeStyles(headerStyle);

const Header = (props) => {
    const classes = useStyles();

    return (
        <>
            <main id="headerSection">
                <Container align="center">
                    <Typography className={classes.heading} variant="h5" > Take Your Next Step </Typography>

                    <Grid container spacing={2}>
                        <Grid item xs={false} md={2}></Grid>
                        <Grid item xs={12} md={3}>
                            <input className={classes.textArea} placeholder="Job title and keywords" />
                        </Grid>
                        <Grid item xs={12} md={3}>
                            <input className={classes.textArea} placeholder="Location" />
                        </Grid>
                        <Grid item xs={12} md={2}>
                            <Button className={classes.btn}> Search </Button>
                        </Grid>
                        <Grid item xs={false} md={2}></Grid>

                    </Grid>


                    <Grid container spacing={2}>
                        <Grid item xs={false} md={2}>
                        </Grid>
                        <Grid item className={classes.respo} xs={12} md={10}>
                            <Button className={classes.link}>Advanced Search</Button>
                        </Grid>
                    </Grid>

                </Container>
            </main>
        </>

    )
}

export default Header                       