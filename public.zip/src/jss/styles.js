export const navBarStyle = {
    root: {
        backgroundColor: '#3097d1',
        padding: '13px 0',
    },
    logo: {
        marginRight: '28px',
    },
    grow: {
        flexGrow: 1,
    },
    menuButton: {
        marginRight: '16px',
    },
    title: {
        padding: '0 14px',
    },
    link: {
        transition: '0.2s ease-in',
        fontWeight: '300',
        fontSize: '16px',
        color: '#fff',

        '&:hover': {
            color: '#e2e2e2',
            textDecoration: 'none',
        }
    },
    icon: {
        width: '12px',
        marginRight: '6px',
    }
}

export const headerStyle = {
    btn: {
        borderRadius: '5px',
        backgroundColor: '#0093d0',
        color: '#fff',
        width: '100%',
        height: '50px',

        '&:hover': {
            backgroundColor: '#2196f3',
        }
    },

    textArea: {
        backgroundColor: '#fff',
        boxSizing: 'border-box',
        borderRadius: '5px',
        width: '100%',
        height: '50px',
        paddingLeft: '22px',
        borderStyle: 'none',
        marginBottom: '14px',
    },
    heading: {
        fontSize: '50px',
        fontWeight: '700',
        marginBottom: '18px',
    },
    link: {
        color: '#fff',
    },
    respo: {
        '@media(min-width: 959px)': {
            textAlign: 'left !important',
        }
    }
}

export const jobCatStyle = {
    root: {
        backgroundColor: '#efefef',
        padding: '18px 20px',
        display: 'flex',
        marginBottom: '8px',
        transition: '0.2s ease -in',
        justifyContent: 'space-between',
        alignItems: 'center',
        color: '#29679f',

        '&:hover': {
            backgroundColor: '#29679f',
            color: '#fff !important',
            borderRadius: '5px',
            cursor: 'pointer',
        },
    },

    circle: {
        backgroundColor: '#fff',
        color: '#2d2d2d',
        borderRadius: '50%',
        fontWeight: '700',
        marginRight: '18px',
        width: '30px',
        height: '30px',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
    },
    typo: {
        fontWeight: '300',
    },
    postion: {
        color: '#444',
        fontWeight: '300',
    }
}

export const ApplyNowStyle = {
    root: {
        width: '100%',
        backgroundColor: '#3097d1',
        color: '#fff',
        padding: '56px 0',
        textAlign: 'center',
        marginBottom: '20px',
    },
    btn: {
        borderRadius: '5px',
        backgroundColor: '#f5b622',
        color: '#222',
        width: '170px',
        height: '50px',
        fontWeight: '700',

        '&:hover': {
            backgroundColor: '#fdc236',
        }
    },
    heading: {
        fontSize: '34px',
        fontWeight: '700',
    },
    subHeading: {
        margin: '6px 0 18px 0',
        fontSize: '18px',
    }
}

export const jobDetailStyle = {
    root: {
        padding: '15px 30px 24px 30px',
        boxShadow: '0px 1px 3px 0px #0000002b',
        borderRadius: '5px',
        marginBottom: '18px',
        transition: '0.4s ease -in',
        backgroundColor: '#ffffff',

        '&:hover': {
            cursor: 'pointer',
            boxShadow: '0 14px 28px rgba(0, 0, 0, 0.25), 0 10px 10px rgba(0, 0, 0, 0.22)',
        },
    },
    jobdisc: {
        fontSize: '16px',
        color: '#6f6f6f',
        lineHeight: '1.5',
    },
    jobDate: {
        fontWeight: '700',
        color: '#29679f',
        marginTop: '5px',
    }
}

export const jobBaordStyle = {
    jobCatTitle: {
        margin: '30px 0 34px 0',
        fontWeight: '700',

        '@media(max-width: 959px)': {
            textAlign: 'center',
        }
    },
    jobDetailTitle: {
        margin: '30px 0 34px 0',
        fontWeight: '700',

        '@media(max-width: 959px)': {
            textAlign: 'center',
        }
    },

    btn: {
        borderRadius: '5px',
        backgroundColor: '#0093d0',
        color: '#fff',
        width: '190px',
        height: '56px',

        '&:hover': {
            backgroundColor: '#2196f3',
        }
    }
}

export const footerStyle = {
    icon: {
        margin: '0 4px 0 4px',
        width: '16px',
    }
}