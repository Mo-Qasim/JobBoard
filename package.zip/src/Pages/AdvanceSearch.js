import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import { jobBaordStyle } from '../jss/styles'
import { Typography, Button, Container, Grid } from '@material-ui/core'

import Navbar from '../components/Navbar'
import Header from '../components/Header'
import HeaderContentAS from '../components/advanceSearch/HeaderCont_AS'
import ApplyNow from '../components/ApplyNow'
import SaveShare from '../components/advanceSearch/SaveShare'
import JobView from '../components/JobView'
import Footer from '../components/Footer'

import job_catogaries from '../API_data/job_cat.json'
import job_detail from '../API_data/job_detail.json'

const useStyles = makeStyles(jobBaordStyle);


const AdvanceSearchWrapper = () => {
    const classes = useStyles();
    return (
        <>
            <Navbar />
            <Header>
                <HeaderContentAS />
            </ Header>

            <div style={{ padding: '60px 0 120px 0' }}>
                <Container>
                    <Grid container spacing={4}>
                        <Grid item xs={12} md={3}>

                        </Grid>

                        <Grid item xs={12} md={9}>
                            <Typography className={classes.jobDetailTitle} variant="h5" > New Opportunities </Typography>
                        </Grid>
                    </Grid>


                    <Grid container spacing={4}>
                        <Grid item xs={12} md={3}>
                            <SaveShare />
                        </Grid>

                        <Grid item xs={12} md={9}>
                            <JobView JobDetail={job_detail} />
                        </Grid>
                    </Grid>

                </Container>
            </div>

            <Footer />
        </>
    )
}

export default AdvanceSearchWrapper