import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { navBarStyle } from '../jss/styles'
import { AppBar, Toolbar, IconButton, Typography, Container, Link } from '@material-ui/core';
import MenuIcon from '@material-ui/icons/Menu'

import logo from '../images/MarathonLogo.png'

import addIcon from '../images/icons/save(w).svg'

const useStyles = makeStyles(navBarStyle);

export default function PrimarySearchAppBar() {
    const [toggle, setToggle] = useState(false);
    const classes = useStyles();
    return (
        <div className={classes.grow}>
            <AppBar className={classes.root} position="relative">
                <Container>
                    <Toolbar>

                        <img className={classes.logo} src={logo} alt="Brand logo" />
                        <div className="desktopMenu">
                            <Typography className={classes.title} variant="h6">
                                <img className={classes.icon} src={addIcon} alt="" />
                                <Link className={classes.link} href="#">
                                    Back to marathonstaffing.com
                             </Link>
                            </Typography>
                            <Typography className={classes.title} variant="h6">
                                <img className={classes.icon} src={addIcon} alt="" />
                                <Link className={classes.link} href="#">
                                    Apply Now
                             </Link>
                            </Typography>
                            <Typography className={classes.title} variant="h6">
                                <img className={classes.icon} src={addIcon} alt="" />
                                <Link className={classes.link} href="#">
                                    Advanced Search
                             </Link>
                            </Typography>
                            <Typography className={classes.title} variant="h6">
                                <img className={classes.icon} src={addIcon} alt="" />
                                <Link className={classes.link} href="#">
                                    Saved Jobs & Searches
                             </Link>
                            </Typography>
                        </div>

                        <div className={classes.grow}>

                        </div>
                        <Typography className={`${classes.title} desktopMenu`} variant="h6">
                            <img className={classes.icon} src={addIcon} alt="" />
                            <Link className={classes.link} href="#">
                                Account Log in
                             </Link>
                        </Typography>
                        <IconButton
                            onClick={() => setToggle(!toggle)}
                            edge="start"
                            style={{ display: 'none' }}
                            className={`${classes.menuButton} showOnmbl`}
                            color="inherit"
                            aria-label="open drawer"
                        >
                            <MenuIcon />
                        </IconButton>

                    </Toolbar>

                </Container>
            </AppBar>


            <div
                className={toggle ? `toggleOn` : 'toggleOff'}>
                <Typography className={classes.title} variant="h6">
                    <img className={classes.icon} src={addIcon} alt="" />
                    <Link className={classes.link} href="#">
                        Back to marathonstaffing.com
                             </Link>
                </Typography>
                <Typography className={classes.title} variant="h6">
                    <img className={classes.icon} src={addIcon} alt="" />
                    <Link className={classes.link} href="#">
                        Apply Now
                             </Link>
                </Typography>
                <Typography className={classes.title} variant="h6">
                    <img className={classes.icon} src={addIcon} alt="" />
                    <Link className={classes.link} href="#">
                        Advanced Search
                             </Link>
                </Typography>
                <Typography className={classes.title} variant="h6">
                    <img className={classes.icon} src={addIcon} alt="" />
                    <Link className={classes.link} href="#">
                        Saved Jobs & Searches
                             </Link>
                </Typography>
                <Typography className={classes.title} variant="h6">
                    <img className={classes.icon} src={addIcon} alt="" />
                    <Link className={classes.link} href="#">
                        Account Log in
                             </Link>
                </Typography>
            </div>
        </div >
    );
}
