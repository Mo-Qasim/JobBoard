import React from 'react'
import { jobDetailStyle } from '../jss/styles'
import { makeStyles } from '@material-ui/core/styles';
import { Typography, Card } from '@material-ui/core'
const useStyles = makeStyles(jobDetailStyle);

const JobView = (props) => {
    const classes = useStyles();
    return (
        <div>
            <div className="jb_flexWrapper">
                <div>
                    <Typography className={classes.jobDate} variant="subtitle2">
                        Job Title
                    </Typography>
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', }}>

                    <Typography className={classes.jobDate} variant="subtitle2">
                        Location
                    </Typography>
                    <Typography className={classes.jobDate} style={{ margin: '5px 18px' }} variant="subtitle2">
                        Office
                    </Typography>
                    <Typography className={classes.jobDate} variant="subtitle2">
                        Date Posted
                    </Typography>
                </div>
            </div>
            {
                props.JobDetail.map((job) => {
                    return (
                        <Card className={classes.root}>

                            <Typography variant="h5"> {job.position} </Typography>
                            <div className="jb_flexWrapper">
                                <div>
                                    <span className="jd_location">{job.location}</span>
                                    <span className="jd_type">{job.type}</span>
                                </div>
                                <div style={{ display: 'flex', flexWrap: 'wrap', }}>

                                    <Typography className={classes.jobDate} variant="subtitle2">
                                        {job.area}
                                    </Typography>
                                    <Typography className={classes.jobDate} style={{ margin: '5px 18px' }} variant="subtitle2">
                                        {job.office}
                                    </Typography>
                                    <Typography className={classes.jobDate} variant="subtitle2">
                                        {job.date}
                                    </Typography>
                                </div>
                            </div>

                            <Typography className={classes.jobdisc} variant="body2" paragraph>
                                {job.job_disc}
                            </Typography>

                        </ Card>
                    )
                })

            }
        </div>
    )
}

export default JobView                                      