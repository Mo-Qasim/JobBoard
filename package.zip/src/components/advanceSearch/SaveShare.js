import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import { headerStyle } from '../../jss/styles'
import { Button, Typography } from '@material-ui/core'
import SaveIcon from '@material-ui/icons/Save';
import ShareIcon from '@material-ui/icons/Share';

const useStyles = makeStyles(headerStyle);

const SaveShare = (props) => {
    const classes = useStyles();

    return (
        <>
            <Typography variant="h6" > All Jobs  <span> {115} </span> </Typography>
            <Typography variant="h6"> Matched Criteria <span> {115} </span> </Typography>

            <Button
                variant="contained"
                fullWidth
                startIcon={<SaveIcon />}
            >
                Save This Job
             </Button>
            <Button
                variant="contained"
                fullWidth
                startIcon={<ShareIcon />}
            >
                Share This Job
             </Button>
        </>

    )
}

export default SaveShare                      