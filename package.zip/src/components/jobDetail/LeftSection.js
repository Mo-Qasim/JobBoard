import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import { Typography, Button, Grid } from '@material-ui/core'

const useStyles = makeStyles({
    btn: {
        position: 'relative',
        borderRadius: '5px',
        backgroundColor: '#0093d0',
        borderRadius: 0,
        color: '#fff',
        width: '100%',
        height: '56px',
        fontWeight: '700',
        textTransform: 'none',
        transition: '0.4s easi-in',

        '&:hover': {
            backgroundColor: '#30c0d8',
        }
    },

    backBtn: {
        backgroundColor: 'transparent',
        border: '2px solid #000',
        color: '#000',

        '&:hover': {
            backgroundColor: '#0093d0',
            border: 'none',
            color: '#fff',
        }
    },
    icon: {
        marginRight: '16px',
    },

    officeWrapper: {
        borderRadius: '8px',
        backgroundColor: '#fff',
        marginBottom: '12px',
        padding: '14px 28px',
    },
    toggleWrapper: {
        display: 'flex',
        justifyContent: 'space-between',
        marginBottom: '18px',
    },
    toggleButton: {
        borderRadius: '5px',
        backgroundColor: '#0093d0',
        borderRadius: 0,
        color: '#fff',
        width: '49%',
        height: '56px',
        fontWeight: '700',
        textTransform: 'none',

        '&:hover': {
            backgroundColor: '#30c0d8',
            color: '#fff'
        }
    },
    active: {
        backgroundColor: '#fff',
        color: '#000',
    },
    applyIcon: {
        position: 'absolute',
        left: '30px',
    },
    text: {
        color: '#222',
        fontSize: '14px',
    },
    NV_title: {
        marginTop: '12px',
        color: '#0093d0',
        fontSize: '16px',
        fontWeight: '700',
    },
    subTitle: {
        marginTop: '10px',
        fontSize: '16px',
        fontWeight: '700',
    },
    NV_wrapper: {
        borderRadius: '8px',
        backgroundColor: '#fff',
        marginBottom: '12px',
        padding: '22px 28px 38px 28px',
    }
});

export default function LeftSection() {
    const classes = useStyles();

    return (
        <div>
            <div className="viewJobsWrapper">
                <Button className={`${classes.btn} ${classes.backBtn}`}> <ArrowBackIcon className={classes.icon} /> Back to Jobs</Button>
            </div>

            <section className={classes.officeWrapper}>
                <Typography className={classes.subTitle} variant="h6">Office</Typography>
                <Typography className={classes.text} variant="subtitle1">
                    NVLasV
                </Typography>

                <Typography className={classes.subTitle} variant="h6">Reference #</Typography>
                <Typography className={classes.text} variant="subtitle1">
                    CES 2020 LV
                </Typography>

                <Typography className={classes.subTitle} variant="h6">Location</Typography>
                <Typography className={classes.text} variant="subtitle1">
                    Las Vegas NV
                </Typography>

                <Typography className={classes.subTitle} variant="h6">Job Category</Typography>
                <Typography className={classes.text} variant="subtitle1">
                    Hospitality
                </Typography>

                <Typography className={classes.subTitle} variant="h6">Compensation </Typography>
                <Typography className={classes.text} variant="subtitle1">
                    $12.66 (hourly)
                </Typography>

                <Typography className={classes.subTitle} variant="h6">Hours per Week</Typography>
                <Typography className={classes.text} variant="subtitle1">
                    29
                </Typography>

                <Typography className={classes.subTitle} variant="h6">Work Schedule</Typography>
                <Typography className={classes.text} variant="subtitle1">
                    Various -
                </Typography>

                <Typography className={classes.subTitle} variant="h6">Duration </Typography>
                <Typography className={classes.text} variant="subtitle1">
                    1 week
                </Typography>

                <Typography className={classes.subTitle} variant="h6">Date Posted</Typography>
                <Typography className={classes.text} variant="subtitle1">
                    12/06/2019
                </Typography>
            </section>

            <Button className={classes.btn}> <AccountCircleIcon className={classes.applyIcon} /> Apply Now </Button>


            <section>

                <br />  <Typography variant="h5">View other jobs in:</Typography> <br />

                <div className={classes.toggleWrapper}>
                    <Button className={classes.toggleButton}> NV </Button>
                    <Button className={`${classes.toggleButton} ${classes.active}`}> Hospitality </Button>
                </div>

                <section className={classes.NV_wrapper}>
                    <Typography className={classes.NV_title} variant="h6">Event Greeters in Las Vegas</Typography>
                    <Typography className={classes.text} variant="subtitle1">
                        Temporary :: Hospitality :: 12/06/2019
                </Typography>
                    <Typography className={classes.NV_title} variant="h6">Event Greeters in Las Vegas</Typography>
                    <Typography className={classes.text} variant="subtitle1">
                        Temporary :: Hospitality :: 12/06/2019
                </Typography>
                    <Typography className={classes.NV_title} variant="h6">Event Greeters in Las Vegas</Typography>
                    <Typography className={classes.text} variant="subtitle1">
                        Temporary :: Hospitality :: 12/06/2019
                </Typography>
                    <Typography className={classes.NV_title} variant="h6">Event Greeters in Las Vegas</Typography>
                    <Typography className={classes.text} variant="subtitle1">
                        Temporary :: Hospitality :: 12/06/2019
                </Typography>
                    <Typography className={classes.NV_title} variant="h6">Event Greeters in Las Vegas</Typography>
                    <Typography className={classes.text} variant="subtitle1">
                        Temporary :: Hospitality :: 12/06/2019
                </Typography>

                    <Typography className={classes.NV_title} variant="h6">Event Greeters in Las Vegas</Typography>
                    <Typography className={classes.text} variant="subtitle1">
                        Temporary :: Hospitality :: 12/06/2019
                </Typography>
                </section>

            </section>

        </div>
    )
}

